
function startGame() {
    var factor = parseInt(document.getElementById('num').value);
    var numberOfProblems = parseInt(document.getElementById('num2').value);
    var operation = document.getElementById('operation').value;
    
    if (!isValidInput(factor, numberOfProblems)) {
        return;
    }
    
    createMathProblems(factor, numberOfProblems, operation);
}

function isValidInput(factor, numberOfProblems) {
    if (isNaN(factor) || isNaN(numberOfProblems) || factor < 1 || factor > 9 || numberOfProblems < 1 || numberOfProblems > 9) {    //ادخال قيم بلتيكسات بين ال 1 و 9
        alert('الرجاء إدخال قيم صحيحة للعوامل وعدد المشكلات (1 إلى 9).');
        return false;
    }
    return true;
}


function createMathProblems(factor, numberOfProblems, operation) {                 
    var resultDiv = document.getElementById('result');
    resultDiv.innerHTML = '';

    for (var i = numberOfProblems; i >= 1; i--) {
        var result = operation === 'add' ? factor + i : factor * i;                //انشاء ليبل وصندوق نص على عدد الرقم المدخل في نمبر اوف بروبلم
        var label = document.createElement('label');
        label.textContent = factor + (operation === 'add' ? ' + ' : ' * ') + i + ' = ';
        resultDiv.appendChild(label);

        var textBox = document.createElement('input');
        textBox.type = 'text';
        resultDiv.appendChild(textBox);

        resultDiv.appendChild(document.createElement('br'));
    }
}


function calculateScore() {
    var textBoxes = document.querySelectorAll('input[type="text"]');        //حساب النتيجه وتلوين التكست اخضر اذا كان صح واحمر اذا كان خطأ

    textBoxes.forEach(function(textBox) {
        var answer = parseInt(textBox.value);
        var label = textBox.previousElementSibling;

        // تجاهل تلوين نص "Player Name:"
        if (label.textContent.trim() !== "Player Name:") {
            if (isNaN(answer)) {
                textBox.style.backgroundColor = 'red';
            } else {
                var factor = parseInt(label.textContent);
                var expectedAnswer = eval(factor);

                if (answer === expectedAnswer) 
                    textBox.style.backgroundColor = 'green';
                 else 
                    textBox.style.backgroundColor = 'red';
                
            }
        }
    });
}






document.getElementById('startGameBtn').addEventListener('click', startGame);                 // تعيين وظائف الأزرار

document.getElementById('scoree').addEventListener('click', calculateScore);
